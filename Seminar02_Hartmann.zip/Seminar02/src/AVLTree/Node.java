package AVLTree;

public class Node {
    public int height;
    int data;
    Node left;
    Node right;
    Node parent;

    public Node(int data) {
        this.data = data;
        left = right = parent = null;
    }
}