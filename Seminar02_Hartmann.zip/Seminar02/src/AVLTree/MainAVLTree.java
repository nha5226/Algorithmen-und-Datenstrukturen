package AVLTree;

public class MainAVLTree {
    public static void main(String[] args) {
        AVLTree tree = new AVLTree();

        // Einfügen von Werten
        tree.insert(55);
        tree.insert(40);
        tree.insert(28);
        tree.insert(10);
        tree.insert(30);
        tree.insert(60);
        tree.insert(95);
        tree.insert(88);
        tree.insert(68);
        tree.insert(90);
        tree.insert(63);
        tree.insert(84);
        tree.insert(99);
        tree.insert(98);
        tree.insert(59);

        // Suche nach einem Wert
        Node node = tree.search(55);
        if (node != null) {
            System.out.println("Dieser Wert wurde gefunden: " + node.data);
        } else {
            System.out.println("Der Wert wurde nicht gefunden." );
        }

        // Entfernen eines Wertes
        tree.remove(99);

        // Minimum und Maximum
        int treeminimum = tree.minimum();
        System.out.println( "Minimum: " + treeminimum);
        int treemaximum = tree.maximum();
        System.out.println("Maximum: " + treemaximum);

        // Predecessor und Successor
        Node predecessor = tree.predecessor(60);
        Node successor = tree.successor(60);

        if (predecessor == null) {
            System.out.println("Predecessor: keine Vorgänger vorhanden.");
        } else {
            System.out.println("Predecessor: " + predecessor.data);
        }
        if(successor == null) {
            System.out.println("Successor: kein Nachfolger vorhanden.");
        } else {
            System.out.println("Successor: " + successor.data);
        }

        // Exportieren des Baums in eine DOT-Datei
        tree.exportToDot("avltree.dot");
    }
}