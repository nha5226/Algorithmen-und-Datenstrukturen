package BinarySearchTree;

import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class BinarySearchTree {
    Node root;

    public BinarySearchTree() {
        root = null;
    }

    public void insert(int data) {
        root = insertRec(root, data);
    }

    Node insertRec(Node root, int data) {
        if (root == null) {
            root = new Node(data);
            return root;
        }
        if (data < root.data)
            root.left = insertRec(root.left, data);
        else if (data > root.data)
            root.right = insertRec(root.right, data);
        return root;
    }

    public Node search(int data) {
        return searchRec(root, data);
    }

    Node searchRec(Node root, int data) {
        if (root == null || root.data == data)
            return root;
        if (root.data > data)
            return searchRec(root.left, data);
        return searchRec(root.right, data);
    }

    public int minimum() {
        Node minv = minimumRec(root);
        return minv.data;
    }

    Node minimumRec(Node node) {
        Node current = node;
        while (current.left != null)
            current = current.left;
        return current;
    }

    public int maximum() {
        Node maxv = maximumRec(root);
        return maxv.data;
    }

    Node maximumRec(Node node) {
        Node current = node;
        while (current.right != null)
            current = current.right;
        return current;
    }

    public Node predecessor(int data) {
        Node node = search(data);
        if (node == null)
            return null;
        if (node.left != null)
            return maximumRec(node.left);
        Node p = node.parent;
        while (p != null && node == p.left) {
            node = p;
            p = p.parent;
        }
        return p;
    }

    public Node successor(int data) {
        Node node = search(data);
        if (node == null)
            return null;
        if (node.right != null)
            return minimumRec(node.right);
        Node p = node.parent;
        while (p != null && node == p.right) {
            node = p;
            p = p.parent;
        }
        return p;
    }

    public void remove(int data) {
        root = removeRec(root, data);
    }

    Node removeRec(Node root, int data) {
        if (root == null)
            return root;
        if (data < root.data)
            root.left = removeRec(root.left, data);
        else if (data > root.data)
            root.right = removeRec(root.right, data);
        else {
            if (root.left == null)
                return root.right;
            else if (root.right == null)
                return root.left;
            root.data = minimumRec(root.right).data;
            root.right = removeRec(root.right, root.data);
        }
        return root;
    }

    public void update(int oldData, int newData) throws Exception {
        Node node = search(oldData);
        if (node == null) {
            throw new Exception("Der alte Wert " + oldData + " existiert nicht im Baum.");
        }
        Node pred = predecessor(oldData);
        Node succ = successor(oldData);
        if ((pred == null || newData > pred.data) && (succ == null || newData < succ.data)) {
            node.data = newData;
        } else {
            throw new Exception("Der neue Wert " + newData + " liegt nicht zwischen dem Vorgänger (" +
                    (pred == null ? "kein" : pred.data) + ") und dem Nachfolger (" +
                    (succ == null ? "kein" : succ.data) + ") des alten Werts " + oldData + ".");
        }
    }

    public void inorder() {
        inorderRec(root);
    }

    void inorderRec(Node root) {
        if (root != null) {
            inorderRec(root.left);
            System.out.print(root.data + " ");
            inorderRec(root.right);
        }
    }

    public void exportToDot(String filename) {
        try (PrintWriter out = new PrintWriter(filename)) {
            out.println("digraph G {");
            exportToDotRec(root, out);
            out.println("}");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    private void exportToDotRec(Node node, PrintWriter out) {
        if (node == null) {
            return;
        }

        if (node.left != null) {
            out.println("    " + node.data + " -> " + node.left.data + ";");
            exportToDotRec(node.left, out);
        }

        if (node.right != null) {
            out.println("    " + node.data + " -> " + node.right.data + ";");
            exportToDotRec(node.right, out);
        }
    }

}