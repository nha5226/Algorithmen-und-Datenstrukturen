package Dijkstra;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        // Erstellen Sie Knoten
        Node a = new Node("A");
        Node b = new Node("B");
        Node c = new Node("C");
        Node d = new Node("D");
        Node v = new Node("V");

        // Erstellen Sie Kanten und fügen Sie sie den Knoten hinzu
        addEdge(v, a, 5);
        addEdge(v, b, 12);
        addEdge(a, c, 3);
        addEdge(a, d, 8);
        addEdge(b, d, 1);
        addEdge(b, c, 2);
        addEdge(c, d, 4);

        // Führen Sie den Dijkstra.Dijkstra-Algorithmus aus
        Dijkstra dijkstra = new Dijkstra();
        dijkstra.execute(v);

        // Drucken Sie die kürzesten Pfade von V zu jedem Knoten
        dijkstra.printShortestPaths(v);

        // Erstellen Sie eine Liste aller Knoten
        List<Node> nodes = Arrays.asList(a, b, c, d, v);

        // Holen Sie sich den Pfad von V nach D
        List<Node> path = dijkstra.getPath(c);

        // Schreiben Sie den Graphen in eine .dot-Datei
        writeGraphToFile(nodes, path, "graph.dot");
    }

    public static void addEdge(Node node1, Node node2, int weight) {
        node1.addEdge(new Edge(node2, weight));
        node2.addEdge(new Edge(node1, weight));
    }

    public static void writeGraphToFile(List<Node> nodes, List<Node> path, String filename) {
        try (PrintWriter writer = new PrintWriter(new File(filename))) {
            writer.println("graph G {");
            for (Node node : nodes) {
                for (Edge edge : node.getEdges()) {
                    // Only write the edge if the source node's name is lexicographically less than the target node's name
                    // This ensures that each edge is only written once
                    if (node.getName().compareTo(edge.getTarget().getName()) < 0) {
                        String color = isPartOfPath(path, node, edge.getTarget()) ? "red" : "black";
                        writer.println("    " + node.getName() + " -- " + edge.getTarget().getName() + " [label=\"" + edge.getWeight() + "\", color=\"" + color + "\"];");
                    }
                }
            }
            writer.println("}");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
    public static boolean isPartOfPath(List<Node> path, Node source, Node target) {
    for (int i = 0; i < path.size() - 1; i++) {
        if ((path.get(i).equals(source) && path.get(i + 1).equals(target)) ||
            (path.get(i).equals(target) && path.get(i + 1).equals(source))) {
            return true;
        }
    }
    return false;
}
}