package Dijkstra;

import java.util.*;

public class Dijkstra {
    private final Map<Node, Integer> distances;
    private final Map<Node, Node> previousNodes;

    public Dijkstra() {
        distances = new HashMap<>();
        previousNodes = new HashMap<>();
    }

    public void execute(Node source) {
    distances.put(source, 0);

    PriorityQueue<Node> queue = new PriorityQueue<>(Comparator.comparingInt(distances::get));
    queue.add(source);

    while (!queue.isEmpty()) {
        Node node = queue.poll();

        for (Edge edge : node.getEdges()) {
            Node target = edge.getTarget();
            int distanceThroughU = distances.get(node) + edge.getWeight();
            if (!distances.containsKey(target) || distanceThroughU < distances.get(target)) {
                distances.put(target, distanceThroughU);
                previousNodes.put(target, node);
                queue.remove(target);  // Remove the node if it's already in the queue
                queue.add(target);  // Add the node with the new distance
            }
        }
    }
}

    public List<Node> getPath(Node target) {
        List<Node> path = new ArrayList<>();
        Node currentNode = target;

        // check if a path exists
        if (previousNodes.get(currentNode) == null) {
            return null;
        }

        path.add(currentNode);
        while (previousNodes.get(currentNode) != null) {
            currentNode = previousNodes.get(currentNode);
            path.add(currentNode);
        }

        // Reverse the order to get the path from source to target
        Collections.reverse(path);
        return path;
    }

    public void printShortestPaths(Node source) {
        System.out.println("Shortest paths from " + source.getName() + ":");
        for (Map.Entry<Node, Integer> entry : distances.entrySet()) {
            System.out.println("To " + entry.getKey().getName() + ": " + entry.getValue());
        }
    }

}