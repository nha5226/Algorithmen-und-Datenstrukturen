package Prim;

import java.util.*;

public class Prim {
    private final Map<Node, Integer> distances;
    private final Map<Node, Node> previousNodes;
    private final List<Edge> minimalSpanningTree;

    public Prim() {
        distances = new HashMap<>();
        previousNodes = new HashMap<>();
        minimalSpanningTree = new ArrayList<>();
    }

    public void execute(Node source) {
        distances.put(source, 0);

        PriorityQueue<Edge> queue = new PriorityQueue<>(Comparator.comparingInt(Edge::getWeight));
        queue.addAll(source.getEdges());

        while (!queue.isEmpty()) {
            Edge edge = queue.poll();
            Node target = edge.getTarget();

            if (!distances.containsKey(target) || edge.getWeight() < distances.get(target)) {
                distances.put(target, edge.getWeight());
                previousNodes.put(target, edge.getSource());
                minimalSpanningTree.add(edge);

                for (Edge e : target.getEdges()) {
                    if (!e.getTarget().equals(edge.getSource())) {
                        queue.add(e);
                    }
                }
            }
        }
    }

    public void printMinimalSpanningTreeInOrder() {
        System.out.println("Minimaler Spannbaum:");
        for (Edge edge : minimalSpanningTree) {
            System.out.println(edge.getSource().getName() + " -- " + edge.getTarget().getName() + " mit wert " + edge.getWeight());
        }
    }

    public List<Node> getPath(Node target) {
        List<Node> path = new ArrayList<>();
        Node currentNode = target;

        // check if a path exists
        if (previousNodes.get(currentNode) == null) {
            return null;
        }

        path.add(currentNode);
        while (previousNodes.get(currentNode) != null) {
            currentNode = previousNodes.get(currentNode);
            if (path.contains(currentNode)) {
                break;
            }
            path.add(currentNode);
        }

        // Reverse the order to get the path from source to target
        Collections.reverse(path);
        return path;
    }

    public void printShortestPaths(Node source) {
        System.out.println("Minimaler Spannbaum vom Knoten " + source.getName() + ":");
        for (Map.Entry<Node, Integer> entry : distances.entrySet()) {
            System.out.println("Knoten " + entry.getKey().getName() + ": " + entry.getValue());
        }
    }

    public void printMinimalSpanningTree(Node source) {
        System.out.println("Minimaler Spannbaum vom Knoten " + source.getName() + ":");
        for (Node node : distances.keySet()) {
            if (node.equals(source)) {
                continue;
            }
            Node previousNode = getPreviousNode(node);
            System.out.println(previousNode.getName() + " zu " + node.getName() + " mit wert " + getEdgeWeight(previousNode, node));
        }
    }

    public int getEdgeWeight(Node node1, Node node2) {
        for (Edge edge : node1.getEdges()) {
            if (edge.getTarget().equals(node2)) {
                return edge.getWeight();
            }
        }
        return Integer.MAX_VALUE;
    }

    public Node getPreviousNode(Node node) {
        return previousNodes.get(node);
    }

    public int getDistance(Node node) {
        return distances.get(node);
    }
}