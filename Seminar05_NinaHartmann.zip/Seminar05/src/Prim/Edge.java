package Prim;

import javax.crypto.spec.PSource;

public class Edge {
    private final Node target;
    private final int weight;
    private final Node source;

    public Edge(Node target, int weight, Node source) {
        this.target = target;
        this.weight = weight;
        this.source = source;
    }

    public Node getSource() {
        return source;
    }

    public Node getTarget() {
        return target;
    }

    public int getWeight() {
        return weight;
    }
}

