package Prim;

import java.util.ArrayList;
import java.util.List;

public class Node {
    private final String name;
    private List<Edge> edges = new ArrayList<>();

    public Node(String name) {
        this.name = name;
    }

    public void addEdge(Edge edge) {
        edges.add(edge);
    }

    public List<Edge> getEdges() {
        return edges;
    }

    public String getName() {
        return name;
    }
}