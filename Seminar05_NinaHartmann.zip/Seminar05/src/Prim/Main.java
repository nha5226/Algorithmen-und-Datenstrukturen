package Prim;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        // Erstellen Sie Knoten
        Node a = new Node("A");
        Node b = new Node("B");
        Node c = new Node("C");
        Node d = new Node("D");
        Node e = new Node("E");
        Node f = new Node("F");
        Node g = new Node("G");

        // Erstellen Sie Kanten und fügen Sie sie den Knoten hinzu
        addEdge(a, b, 14);
        addEdge(a, d, 10);
        addEdge(b, c, 16);
        addEdge(b, e, 13);
        addEdge(b, d, 18);
        addEdge(c, e, 9);
        addEdge(d, e, 30);
        addEdge(d, f, 17);
        addEdge(f, g, 22);
        addEdge(d, g, 12);
        addEdge(e, g, 16);


        // Führen Sie den Algorithmus aus
        Prim prim = new Prim();
        prim.execute(f);
        prim.printMinimalSpanningTreeInOrder();

        // Drucken Sie den minimalen Spannbaum von V
        prim.printMinimalSpanningTree(f);

        // Erstellen Sie eine Liste aller Knoten
        List<Node> nodes = Arrays.asList(a, b, c, d, e, f, g);

        // Schreiben Sie den Graphen in eine .dot-Datei
        writeGraphToFile(prim, nodes, "prim.dot");
    }

    private static void addEdge(Node source, Node target, int weight) {
        Edge edge = new Edge(target, weight, source);
        source.addEdge(edge);
        target.addEdge(edge);
    }

    public static void writeGraphToFile(Prim prim, List<Node> nodes, String filename) {
        try (PrintWriter writer = new PrintWriter(new File(filename))) {
            writer.println("graph G {");
            for (Node node : nodes) {
                Node previousNode = prim.getPreviousNode(node);
                if (previousNode != null) {
                    int weight = prim.getEdgeWeight(previousNode, node);
                    writer.println("    " + previousNode.getName() + " -- " + node.getName() + " [label=\"" + weight + "\", color=\"black\"];");
                }
            }
            writer.println("}");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}