import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class Main {
    public static void main(String... arg) {
        Heap minHeap = new Heap(15);
        minHeap.insert(5);
        minHeap.insert(17);
        minHeap.insert(10);
        minHeap.insert(84);
        minHeap.insert(19);
        minHeap.insert(6);
        minHeap.insert(22);
        minHeap.insert(9);

        // print Heap bevor extractMin
        String heap = minHeap.toDot();

        try (BufferedWriter writer = new BufferedWriter(new FileWriter("heap.dot"))) {
            writer.write(heap);
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println("Die kleinste Zahl ist: " + minHeap.extractMin());

        // print Heap after extractMin
        String heapExtractMin = minHeap.toDot();

        try (BufferedWriter writer = new BufferedWriter(new FileWriter("heapExtractMin.dot"))) {
            writer.write(heapExtractMin);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}