package ShortestWay;

import java.util.*;

public class Graph {
    Map<String, List<String>> adjacencyList;
    private Map<String, Map<String, String>> nodeAttributes;
    private Map<Edge, Map<String, String>> edgeAttributes;
    List<String> shortestPath = new ArrayList<>();
    int shortestDistance = Integer.MAX_VALUE;

    public Graph() {
        adjacencyList = new HashMap<>();
        nodeAttributes = new HashMap<>();
        edgeAttributes = new HashMap<>();
    }


    public void addNode(String node, Map<String, String> attributes) {
        adjacencyList.put(node, new ArrayList<>());
        nodeAttributes.put(node, attributes);
    }

    public void addEdge(String node1, String node2, int weight) {
        // Add the edge to the adjacency list
        adjacencyList.computeIfAbsent(node1, k -> new ArrayList<>()).add(node2);
        adjacencyList.computeIfAbsent(node2, k -> new ArrayList<>()).add(node1);

        // Add the edge attributes
        Map<String, String> edgeAttr = new HashMap<>();
        edgeAttr.put("weight", String.valueOf(weight));
        edgeAttributes.put(new Edge(node1, node2), edgeAttr);
    }

    public List<String> getNeighbors(String node) {
        return adjacencyList.getOrDefault(node, new ArrayList<>());
    }

    public void setNodeAttributes(String node, Map<String, String> attributes) {
        nodeAttributes.put(node, attributes);
    }

    public void setEdgeAttributes(String node1, String node2, Map<String, String> attributes) {
        edgeAttributes.put(new Edge(node1, node2), attributes);
    }

    private static class Edge {
        private String node1;
        private String node2;

        public Edge(String node1, String node2) {
            this.node1 = node1;
            this.node2 = node2;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) return true;
            if (obj == null || getClass() != obj.getClass()) return false;
            Edge edge = (Edge) obj;
            return (node1.equals(edge.node1) && node2.equals(edge.node2)) ||
                    (node1.equals(edge.node2) && node2.equals(edge.node1));
        }

        @Override
        public int hashCode() {
            return Objects.hash(node1, node2) + Objects.hash(node2, node1);
        }
    }

    public List<String> shortestPath(String start, String end) {
        List<String> path = new ArrayList<>();
        path.add(start);
        findPaths(start, end, path, 0, Integer.MAX_VALUE, new ArrayList<>());
        return shortestPath;
    }

    private void findPaths(String current, String end, List<String> path, int distance, int shortestDistance, List<String> visited) {
        if (distance > shortestDistance) return;
        if (current.equals(end)) {
            if (distance < this.shortestDistance) {
                this.shortestDistance = distance;
                this.shortestPath = new ArrayList<>(path);
            }
            return;
        }
        visited.add(current);
        for (String neighbor : getNeighbors(current)) {
            if (!visited.contains(neighbor)) {
                path.add(neighbor);
                findPaths(neighbor, end, path, distance + getEdgeWeight(current, neighbor), shortestDistance, visited);
                path.remove(path.size() - 1);
            }
        }
        visited.remove(visited.size() - 1);
    }

    private int getEdgeWeight(String node1, String node2) {
       return Integer.parseInt(edgeAttributes.get(new Edge(node1, node2)).get("weight"));
    }
}
