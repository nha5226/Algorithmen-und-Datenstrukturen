package ShortestWay;

import java.io.*;
import java.util.List;


public class Main {
    public static void main(String[] args) {
        String inputFile = "C:\\Users\\Nina\\6. Semester\\Algorithmen und Datenstrukturen\\Seminar\\Code\\Seminar04\\src\\ShortestWay\\shortestWay.txt";
        String outputFile = "shortestway.dot";

        Graph graph = new Graph();
        populateGraph(graph, inputFile);

        List<String> shortestPath = graph.shortestPath("B", "D"); // Replace with your start and end nodes



        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));
             PrintWriter writer = new PrintWriter(new FileWriter(outputFile))) {

            writer.println("graph G {");

            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\\s+");
                if (parts.length >= 3) {
                    String node1 = parts[0];
                    String node2 = parts[1];
                    String value = parts[2];

                    // Check if this edge is part of the shortest path
                    for (int i = 0; i < shortestPath.size() - 1; i++) {
                        if ((shortestPath.get(i).equals(node1) && shortestPath.get(i + 1).equals(node2)) ||
                                (shortestPath.get(i).equals(node2) && shortestPath.get(i + 1).equals(node1))) {
                            writer.println("  " + node1 + " -- " + node2 + " [label=\"" + value + "\", color=\"pink\", penwidth=5.0];");
                            break;
                        } else if (i == shortestPath.size() - 2) {
                            writer.println("  " + node1 + " -- " + node2 + " [label=\"" + value + "\"];");
                        }
                    }
                }
            }

            writer.println("}");

            System.out.println("DOT file created successfully: " + outputFile);

            System.out.println("Shortest path: " + shortestPath);
        } catch (IOException e) {
            System.err.println("Error reading or writing files: " + e.getMessage());
        }
    }

    private static void populateGraph(Graph graph, String inputFile) {
        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\\s+");
                if (parts.length >= 3) {
                    String node1 = parts[0];
                    String node2 = parts[1];
                    int weight = Integer.parseInt(parts[2]);
                    graph.addEdge(node1, node2, weight);
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
        }
    }
}


