## Dokumentation

Hier in dieser Datei wird die Funktionsweise des Programms beschrieben und erklärt wie die einzelnen Aufgaben gestartet werden.


### Graph

Die Datei wird mit der `Main` Klasse ausgeführt. Hier wird ein Graph erstellt und die einzelnen Knoten und Kanten hinzugefügt. Der Graph kann dann mithilfe des __PlantUML__ Plugins angezeigt werden, indem man die graph.dot Datei öffnet. 
Um einzelne Knoten, Kanten oder der Wert der Kanten hinzuzufügen, muss man in der `graph.txt` Datei alles eintragen. 
Man muss es wie folgt eintragen: 
```
node1 node2 Wert
node1 node2 Wert
node1 node2 Wert
```

node1 und node2 sind die Namen der Knoten und Wert ist der Wert der Kante.

### Shortest Way

Beim Shortest Way Problem wird die `Main` Klasse ausgeführt. Der Graph kann dann mithilfe des __PlantUML__ Plugins angezeigt.
Hier wird mithilfe von Tiefensuche der kürzeste Weg zwischen zwei Knoten gefunden.
Genau wie beim Graph wird auch hier aus einer .txt Datei der Graph erstellt.


### Nikolaus
Beim Nikolaus Problem wird die `Main` Klasse ausgeführt. Hier wird ein Graph erstellt und die einzelnen Knoten und Kanten hinzugefügt. Der Graph kann dann mithilfe des __PlantUML__ Plugins angezeigt. Hier ist es wichtig zu wissen, ob der Graph einen Eulerpfad hat oder nicht.
Hier muss man die Knoten und Kanten jeweils einzeln in der `Main` Klasse hinzufügen.
Ob es dann ein Eulerpfad ist oder nicht wird in der Konsole ausgegeben.

