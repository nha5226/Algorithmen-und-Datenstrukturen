package Nikolaus;

import java.util.Objects;

public class Edge {
    private final String node1;
    private final String node2;

    public Edge(String node1, String node2) {
        this.node1 = node1;
        this.node2 = node2;
    }

    public String getNode1() {
        return node1;
    }

    public String getNode2() {
        return node2;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Edge edge = (Edge) obj;
        return (node1.equals(edge.node1) && node2.equals(edge.node2)) ||
                (node1.equals(edge.node2) && node2.equals(edge.node1));
    }

    @Override
    public int hashCode() {
        return Objects.hash(node1, node2) + Objects.hash(node2, node1);
    }
}