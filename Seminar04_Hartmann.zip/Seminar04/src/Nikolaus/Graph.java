package Nikolaus;

import java.util.*;

public class Graph {
    private final Map<String, List<String>> adjacencyList = new HashMap<>();

    public void addNode(String node) {
        adjacencyList.putIfAbsent(node, new ArrayList<>());
    }

    public void addEdge(Edge edge) {
        adjacencyList.putIfAbsent(edge.getNode1(), new ArrayList<>());
        adjacencyList.putIfAbsent(edge.getNode2(), new ArrayList<>());
        adjacencyList.get(edge.getNode1()).add(edge.getNode2());
        adjacencyList.get(edge.getNode2()).add(edge.getNode1());
    }

    public boolean hasEulerPath() {
        int oddDegreeNodes = 0;
        for (List<String> neighbors : adjacencyList.values()) {
            if (neighbors.size() % 2 != 0) {
                oddDegreeNodes++;
            }
        }
        return oddDegreeNodes == 0 || oddDegreeNodes == 2;
    }

    public List<Edge> findEulerPath() {
        if (!hasEulerPath()) {
            return null;
        }

        String startNode = findStartNode();
        List<Edge> path = new ArrayList<>();
        Stack<String> stack = new Stack<>();
        stack.push(startNode);

        while (!stack.isEmpty()) {
            String node = stack.peek();
            if (adjacencyList.get(node).isEmpty()) {
                stack.pop();
            } else {
                String neighbor = adjacencyList.get(node).get(0);
                stack.push(neighbor);
                adjacencyList.get(node).remove(neighbor);
                adjacencyList.get(neighbor).remove(node);
                path.add(new Edge(node, neighbor));
            }
        }

        Collections.reverse(path);
        return path;
    }

    private String findStartNode() {
        for (Map.Entry<String, List<String>> entry : adjacencyList.entrySet()) {
            if (entry.getValue().size() % 2 != 0) {
                return entry.getKey();
            }
        }
        return adjacencyList.keySet().iterator().next();
    }

    public String toDot(List<Edge> eulerPath) {
        StringBuilder sb = new StringBuilder();
        sb.append("graph G {\n");

        // Add nodes
        for (String node : adjacencyList.keySet()) {
            sb.append("    ").append(node).append(";\n");
        }

        // Add edges
        for (Edge edge : eulerPath) {
            sb.append("    ").append(edge.getNode1()).append(" -- ").append(edge.getNode2());
            if (eulerPath.contains(edge)) {
                sb.append(" [color=black]");
            }
            sb.append(";\n");
        }

        sb.append("}");
        return sb.toString();
    }
}
