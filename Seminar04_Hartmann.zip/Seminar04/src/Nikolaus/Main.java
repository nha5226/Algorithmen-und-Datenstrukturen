package Nikolaus;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Graph graph = new Graph();

        // Knoten hinzufügen
        graph.addNode("1");
        graph.addNode("2");
        graph.addNode("3");
        graph.addNode("4");
        graph.addNode("5");

        // Kanten hinzufügen
        graph.addEdge(new Edge("1", "2"));
        graph.addEdge(new Edge("1", "4"));
        graph.addEdge(new Edge("1", "5"));
        graph.addEdge(new Edge("2", "3"));
        graph.addEdge(new Edge("2", "4"));
        graph.addEdge(new Edge("3", "5"));
        graph.addEdge(new Edge("4", "3"));

        // Überprüfen, ob der Graph einen Eulerpfad hat
        if (graph.hasEulerPath()) {
            System.out.println("Der Graph hat einen Eulerpfad.");

            // Den Eulerpfad finden und ausgeben
            List<Edge> eulerPath = graph.findEulerPath();

            // Den Graphen und den Eulerpfad in .dot-Syntax ausgeben
            String dot = graph.toDot(eulerPath);
            try (PrintWriter out = new PrintWriter("Nikolaus.dot")) {
                out.println(dot);
            } catch (IOException e) {
                System.out.println("Ein Fehler ist aufgetreten beim Schreiben der Datei: " + e.getMessage());
            }
        } else {
            System.out.println("Der Graph hat keinen Eulerpfad.");
        }
    }
}