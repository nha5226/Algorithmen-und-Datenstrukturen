package Graph;

import java.io.*;
public class Main {
    public static void main(String[] args) {
        String inputFile = "C:\\Users\\Nina\\6. Semester\\Algorithmen und Datenstrukturen\\Seminar\\Code\\Seminar04\\src\\Graph\\graph.txt";
        String outputFile = "graph.dot";

        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));
             PrintWriter writer = new PrintWriter(new FileWriter(outputFile))) {

            writer.println("graph G {");

            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\\s+");
                if (parts.length >= 3) {
                    String node1 = parts[0];
                    String node2 = parts[1];
                    String value = parts[2];
                    writer.println("  " + node1 + " -- " + node2 + " [label=\"" + value + "\"];");
                }
            }

            writer.println("}");

            System.out.println("DOT file created successfully: " + outputFile);

        } catch (IOException e) {
            System.err.println("Error reading or writing files: " + e.getMessage());
        }
    }
}


