package Graph;

import java.util.*;

public class Graph {
    Map<String, List<String>> adjacencyList;
    private Map<String, Map<String, String>> nodeAttributes;
    private Map<Edge, Map<String, String>> edgeAttributes;

    public Graph() {
        adjacencyList = new HashMap<>();
        nodeAttributes = new HashMap<>();
        edgeAttributes = new HashMap<>();
    }

    public void addNode(String node, Map<String, String> attributes) {
        adjacencyList.put(node, new ArrayList<>());
        nodeAttributes.put(node, attributes);
    }

    public void addEdge(String node1, String node2, Map<String, String> attributes, String value) {
        adjacencyList.get(node1).add(node2);
        adjacencyList.get(node2).add(node1);
        Map<String, String> edgeAttr = new HashMap<>(attributes);
        edgeAttr.put("value", value);
        edgeAttributes.put(new Edge(node1, node2), edgeAttr);
    }

    public List<String> getNeighbors(String node) {
        return adjacencyList.getOrDefault(node, new ArrayList<>());
    }

    public void setNodeAttributes(String node, Map<String, String> attributes) {
        nodeAttributes.put(node, attributes);
    }

    public void setEdgeAttributes(String node1, String node2, Map<String, String> attributes) {
        edgeAttributes.put(new Edge(node1, node2), attributes);
    }

    private static class Edge {
        private String node1;
        private String node2;

        public Edge(String node1, String node2) {
            this.node1 = node1;
            this.node2 = node2;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) return true;
            if (obj == null || getClass() != obj.getClass()) return false;
            Edge edge = (Edge) obj;
            return (node1.equals(edge.node1) && node2.equals(edge.node2)) ||
                    (node1.equals(edge.node2) && node2.equals(edge.node1));
        }

        @Override
        public int hashCode() {
            return Objects.hash(node1, node2) + Objects.hash(node2, node1);
        }
    }
}
