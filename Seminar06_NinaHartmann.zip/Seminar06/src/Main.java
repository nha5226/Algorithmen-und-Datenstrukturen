public class Main {
    public static void main(String[] args) {
        // Initial state: all figures are on the left side
        GameState startState = new GameState(0b1111);

        // Solve the problem using depth-first search
        GameState solutionDFS = Search.search(startState, true);
        if (solutionDFS != null) {
            System.out.println("Solution found using depth-first search!");
        } else {
            System.out.println("No solution found using depth-first search.");
        }

        // Solve the problem using breadth-first search
        GameState solutionBFS = Search.search(startState, false);
        if (solutionBFS != null) {
            System.out.println("Solution found using breadth-first search!");
        } else {
            System.out.println("No solution found using breadth-first search.");
        }
    }
}