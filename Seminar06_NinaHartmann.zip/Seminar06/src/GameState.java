import java.util.ArrayList;
import java.util.List;

public class GameState {
    private int state;

    public GameState(int state) {
        this.state = state;
    }

    public boolean isWolfOnLeft() {
        return (state & 0b1000) != 0;
    }

    public boolean isSheepOnLeft() {
        return (state & 0b0100) != 0;
    }

    public boolean isCabbageOnLeft() {
        return (state & 0b0010) != 0;
    }

    public boolean isFarmerOnLeft() {
        return (state & 0b0001) != 0;
    }

    public List<GameState> generateSuccessors() {
        List<GameState> successors = new ArrayList<>();
        for (int i = 0; i < 4; i++) {
            if (((state >> i) & 1) == (state & 1)) {
                int newState = state ^ ((1 << i) | 1);
                successors.add(new GameState(newState));
            }
        }
        return successors;
    }

    public boolean isValid() {
        // Invalid if the wolf and the sheep are together without the farmer,
        // or if the sheep and the cabbage are together without the farmer
        return !((isWolfOnLeft() == isSheepOnLeft() && isFarmerOnLeft() != isSheepOnLeft()) ||
                 (isSheepOnLeft() == isCabbageOnLeft() && isFarmerOnLeft() != isSheepOnLeft()));
    }

    public boolean isTerminationState() {
        // All figures are on the right side
        return state == 0;
    }

    @Override
    public GameState clone() {
        return new GameState(state);
    }

    @Override
    public int hashCode() {
        return state;
    }
}