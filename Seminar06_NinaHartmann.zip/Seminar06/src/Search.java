import java.util.*;

public class Search {
    public static GameState search(GameState start, boolean useDepthFirst) {
        Set<Integer> visited = new HashSet<>();
        Deque<GameState> frontier = useDepthFirst ? new ArrayDeque<>() : new LinkedList<>();

        frontier.add(start);

        while (!frontier.isEmpty()) {
            GameState current = frontier.remove();

            if (visited.contains(current.hashCode())) {
                continue;
            }

            visited.add(current.hashCode());

            if (current.isTerminationState()) {
                return current;
            }

            for (GameState successor : current.generateSuccessors()) {
                if (!visited.contains(successor.hashCode())) {
                    frontier.add(successor);
                }
            }
        }

        return null;
    }
}