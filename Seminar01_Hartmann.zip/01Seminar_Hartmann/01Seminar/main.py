import matplotlib.pyplot as plt
import time
import random
import threading

def generate_matrix(n):
    return [[random.randint(1, 25) for _ in range(n)] for _ in range(n)]

# 1. for c1 * n
# 2. for c2 * n * n


def add_matrices(a, b):
    return [[a[i][j] + b[i][j] for j in range(len(a[0]))] for i in range(len(a))]

# for j c1 * n
# for i c2 * n * n


def multiply_matrices(a, b):
    result = [[0 for _ in range(len(b[0]))] for _ in range(len(a))]
    for i in range(len(a)):
        for j in range(len(b[0])):
            for k in range(len(b)):
                result[i][j] += a[i][k] * b[k][j]
    return result

# c1 * n * n
# c2 * n
# c3 * n * n
# c4 * n * n * n
# c5 * n * n * n

# n^3 = an^3 + bn^2 + cn + d


addition_runtimes = []
multiplication_runtimes = []
generation_runtimes = []
sizes = []
total = []

def matrix_operations():
    n = 0
    while True:
        start_time = time.time()
        matrix1 = generate_matrix(n)
        matrix2 = generate_matrix(n)
        end_time = time.time()
        generation_runtimes.append(end_time - start_time)

        start_time = time.time()
        add_matrices(matrix1, matrix2)
        end_time = time.time()
        addition_runtimes.append(end_time - start_time)

        start_time = time.time()
        multiply_matrices(matrix1, matrix2)
        end_time = time.time()
        multiplication_runtimes.append(end_time - start_time)

        total.append(generation_runtimes[-1] + addition_runtimes[-1] + multiplication_runtimes[-1])

        sizes.append(n)

        n += 30
        plot_runtimes()

def plot_runtimes():
    plt.plot(sizes, addition_runtimes, label='Addition')
    plt.plot(sizes, multiplication_runtimes, label='Multiplication')
    plt.plot(sizes, generation_runtimes, label='Generation')
    plt.plot(sizes, total, label='Total')
    plt.xlabel('Matrix size')
    plt.ylabel('Runtime (seconds)')
    plt.legend()
    plt.pause(4)

thread1 = threading.Thread(target=matrix_operations)

thread1.start()